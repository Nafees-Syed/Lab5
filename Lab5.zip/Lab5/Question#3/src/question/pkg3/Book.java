/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg3;

/**
 * Write a class encapsulating the concept of a book. The attributes of a book
 * are title, author, ISBN and year of publishing. The class has a static
 * attribute publisher initialized as "Vanier", and an amountOfBooks, which is
 * initially zero. Include a constructor, accessors and mutators, and the
 * methods toString and equals. Every time a new object is instantiated, the
 * class variable amountOfBooks is incremented by 1. When a book object is
 * printed, it should output all its attributes in a nice way. Two books are
 * considered equal if they have the same ISBN. Make sure you have at least one
 * method that uses the object reference this. Write a client class to test all
 * the methods in your Book class. Also test if two book objects share the same
 * values for the publisher and amountOfBooks.
 *
 * @author Nafees Syed
 */
public class Book {

    private String title;
    private String author;
    private long isbn;
    private int yearOfPublishing;
    private static String publisher = "Vanier";
    private static int amountOfBooks = 0;
   
    
    public Book(){
        amountOfBooks++;
        this.title = "Empty";
        this.author = "Empty";
        this.isbn = 0;
        this.yearOfPublishing = 0;
    }

    public Book(String title, String author, long isbn, int yearOfPublishing) {
        amountOfBooks++;        
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.yearOfPublishing = yearOfPublishing;

    }
    
    //make the settors method (accessor)

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setIsbn(long isbn) {
        this.isbn = isbn;
    }

    public void setYearOfPublishing(int yearOfPublishing) {
        this.yearOfPublishing = yearOfPublishing;
    }

    public void setPublisher(String publiher) {
        this.publisher = publisher;
    }

    public void setAmountOfBooks(int amountOfBooks) {
        this.amountOfBooks = amountOfBooks;
    }
    
    //make the getter methods (Mutator)
    
    public String getTitle(){
        return title;
    }
    
    public String setAuthor(){
        return author;
    }
    
    public long setIsbn(){
        return isbn;
    }
    
    public int setYearOfPublishing(){
        return yearOfPublishing;
    }
    
    public String setPublisher(){
        return publisher;
    }
    
    public int setAmountOfBooks(){
        return amountOfBooks;
    }
    
    public boolean equals(Book other){
        //Two books are considered equal if they have the same ISBN
        if(this.isbn != other.isbn)return false;
        return true;
    }
    
    @Override
    public String toString(){
        
        String result = "";
        
        result += "      ~BOOK INFO~     ";
        result += "\n----------------------";
        result += "\nTitle: " + this.title;
        result += "\nAuthor: " + this.author;
        result += "\nISBN: " + this.isbn;
        result += "\nYear of publishing: " + this.yearOfPublishing;
        result += "\nPublisher: " + this.publisher;
        result += "\nAmount of Books: " + this.amountOfBooks + "\n";
        return result;

    }

}
