/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg58;

/**
 * Write a class encapsulating the concept of a course grade, assuming a course
 * has the following attributes: a code (for instance, CSI), a description, and
 * a number of credits (for instance, 3). Include a constructor, the accessors
 * and mutators, and the methods toString. Write a client class to test all the
 * methods in your class.
 *
 * @author Natsu
 */
public class Course {

    private String code;
    private String descr;
    private int credit;

    public Course() {
        this.code = "Empty";
        this.descr = "Empty";
        this.credit = 0;
    }

    public Course(String code, String descr, int credit) {
        this.code = code;
        this.descr = descr;
        this.credit = credit;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    public String getCode() {
        return code;
    }

    public String getDescr() {
        return descr;
    }

    public int getCredit() {
        return credit;
    }

    public boolean equals(Course other) {
        if (!this.code.equals(other.code)) {
            return false;
        }
        if (!this.descr.equals(other.descr)) {
            return false;
        }
        if (this.credit != other.credit) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String result = "";

        result += "\n  ~Course Grade~";
        result += "\nCourse code: " + this.code;
        result += "\nCourse description: " + this.descr;
        result += "\nCourse credit: " + this.credit;
        return result;
    }
}
