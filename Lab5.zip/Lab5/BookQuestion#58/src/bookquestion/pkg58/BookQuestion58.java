/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg58;

/**
 * Write a class encapsulating the concept of a course grade, assuming a course
 * has the following attributes: a code (for instance, CSI), a description, and
 * a number of credits (for instance, 3). Include a constructor, the accessors
 * and mutators, and the methods toString. Write a client class to test all the
 * methods in your class.
 *
 * @author Natsu
 */
public class BookQuestion58 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Course c1 = new Course();
        Course c2 = new Course("PRG", "This programming class will help you to understand and "
                + "\n                  learn about the worl of java programming", 3);
        Course c3 = new Course("KA", "The killing Art course will show and teach students the"
                + "\n                 most effective way to commit murder so that after graduation they will be full "
                + "\n                 fledge contract killers.", 10);
        
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
    }

}
