/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import java.io.*;
import java.util.*;

/**
 *
 * @author my_as
 */
public class Testing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        File inFile = new File("C:\\Users\\my_as\\Desktop\\Lab5\\test.txt");
        Scanner scFile = new Scanner(inFile);

        int counter = 0;
        while (scFile.hasNext()) {
            counter++;
            String line = scFile.nextLine();
            System.out.println("Line #" + counter + ": " + line);
            if (line.equals("FLAG"))
                break;

        }
    }

}
