/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg57;

/**
 * Write a class encapsulating the concept of a course grade, assuming a course 
 * grade has the following attributes: a course name and a letter grade. Include 
 * a constructor, the accessors and mutators, and methods toString and equals.
 * Write a client class to test all the methods in your class.
 * 
 * @author Natsu
 */
public class Grading {
    private String name;
    private String grade;
    
    public Grading(){
        this.name = "Life";
        this.grade = "-F";
    }
    
    public Grading(String name, String grade){
        this.name = name;
        this.grade = grade;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public void setGrade(String grade){
        this.grade = grade;
    }
    
    public String getName(){
        return name;
    }
    
    public String getGrade(){
        return grade;
    }
    
    public boolean equals(Grading other){
        if(! this.name.equals(other.name)) return false;
        if(! this.grade.equals(other.grade)) return false;
        return true;
    }
    
    @Override
    public String toString(){
        
        String result = "";
        
        result += "\n  ~Report Card~";
        result += "\nClass name: " + this.name;
        result += "\nGrade: " + this.grade;
        return result;
        
    }
    
    
}
