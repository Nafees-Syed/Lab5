/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg57;

/**
 *
 * @author Natsu
 */
public class BookQuestion57 {

    /**
     * Write a class encapsulating the concept of a course grade, assuming a course 
     * grade has the following attributes: a course name and a letter grade. Include 
     * a constructor, the accessors and mutators, and methods toString and equals.
     * Write a client class to test all the methods in your class.
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Grading marks1 = new Grading();
        Grading marks2 = new Grading("English", "A");
        Grading marks3 = new Grading("French", "C");
        Grading marks4 = new Grading("How to Fail in Life", "A+++");
        
        System.out.println(marks1);
        System.out.println(marks2);
        System.out.println(marks3);
        System.out.println(marks4);
    }
    
}
