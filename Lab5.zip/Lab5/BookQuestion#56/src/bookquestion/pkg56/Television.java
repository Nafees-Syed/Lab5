/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg56;

/**
 * Write a class encapsulating the concepts of a television set, assuming a 
 * television set has the following attributes: a brand and a price. Include a 
 * constructor, the accessors and the mutators, and methods toString and equals.
 * Write a client class to test all methods in your class.
 * 
 * @author Natsu
 */
public class Television {
    private String brand;
    private double price;
    
    public Television(){
        this.brand = "Empty";
        this.price = 0;
    }
    
    public Television(String brand, double price){
        this.brand = brand;
        this.price = price;
    }
    
    public void setBrand(String brand){
        this.brand = brand;
    }
    
    public void setPrice(double price){
        this.price = price;
    }
    
    public String getBrand(){
        return brand;
    }
    
    public double getPrice(){
        return price;
    }
    
    public boolean equals(Television other){
        
        if(! this.brand.equals(other.brand))return false;
        if(this.price != other.price)return false;
        return true;
    }
    @Override
    public String toString(){
        String result = "";
        
        result += "     ~Television~\n";
        result += "Brand name: " + this.brand;
        result += "\nPrice: " + this.price + "$\n";
        
        return result;
        
    }
    
}
