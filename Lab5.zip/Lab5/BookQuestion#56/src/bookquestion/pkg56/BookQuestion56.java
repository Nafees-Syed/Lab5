/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookquestion.pkg56;

import java.util.*;

/**
 * Write a class encapsulating the concepts of a television set, assuming a
 * television set has the following attributes: a brand and a price. Include a
 * constructor, the accessors and the mutators, and methods toString and equals.
 * Write a client class to test all methods in your class.
 *
 * @author Natsu
 */
public class BookQuestion56 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);

        System.out.print("Enter the name of the brand: ");
        String nameB = kb.next();

        System.out.print("Enter the price of the TV: " );
        double priceTV = kb.nextDouble();
        
        Television tv1 = new Television();
        Television tv2 = new Television(nameB, priceTV);
        Television tv3 = new Television("Toshiba", 560.99);

        System.out.println(tv1);
        System.out.println(tv2);
        System.out.println(tv3);

    }

}
