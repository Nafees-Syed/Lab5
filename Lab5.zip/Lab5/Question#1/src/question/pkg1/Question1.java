package question.pkg1;

import java.util.*;
import java.io.*;

/**
 * Write a program that reads a file containing a list of names and scores. The
 * program should identify and outputs the name with the highest and lowest
 * score, the total amount of grades processed, and the average score of all
 * processed.
 *
 * @author Nafees Syed Date: 18 April 2020
 */
public class Question1 {

    public static void main(String[] args) throws FileNotFoundException {
        File inFile = new File("C:\\Users\\Natsu\\Desktop\\Lab5\\Name&Score.txt");
        Scanner scFile = new Scanner(inFile);

        double high = 0;
        double low = 100;
        double addition = 0;
        double number = 0;
        String nameLow = "";
        String nameHigh = "";
        int count = 0;

        while (scFile.hasNext()) {
            String line = scFile.next();
            double grade = scFile.nextDouble();
            if (high < grade) {
                high = grade;
                nameHigh = line;
            }

            if (low > grade) {
                low = grade;
            nameLow = line;
            }
            addition = number + grade;
            number = addition;

            ++count;
        }
        double average = addition / count;
        
        System.out.println("The person with the Highest score is: " + nameHigh + "(congratulations keep doing a good work!!)");
        System.out.println("The person with the Lowest score is: " + nameLow + 
                           "(You are a huge dissapointment...are you even trying at all?");
        System.out.println("Their is " + count + " scores");
        System.out.println("The overall Average is: " + average);
                

    }

}
