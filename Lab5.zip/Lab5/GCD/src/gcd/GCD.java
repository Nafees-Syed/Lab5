/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

import java.util.*;

/**
 * Write a program to compute the greatest common divisor (gcd) of two integers.
 * in mathematics, the gcd of two or more integers is the largest positive
 * integer that divides each of the integers. For example, the gcd of 8 and 12
 * is 4; the gcd of 24 and 16 is 8. Your program should provide a type-safe
 * input. It should not crash of either number is not integers, or even of it is
 * not a number.
 *
 * @author Nafees Syed Date: 18 April 2020
 */
public class GCD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner kb = new Scanner(System.in);

        System.out.println("Enter 2 integers: ");

        String garbage;

        while (!kb.hasNextInt()) {
            garbage = kb.nextLine();
            System.out.println("You have not entered an Integer!");
            System.out.println("Please Enter an Integer");

        }
        int num1 = kb.nextInt();
        System.out.println("Integer #1: " + num1);

        String garbage2;
        while (!kb.hasNextInt()) {
            garbage2 = kb.nextLine();
            System.out.println("You have not entered an Integer!");
            System.out.println("Please Enter an Integer");

        }
        int num2 = kb.nextInt();
        System.out.println("Integer #2: " + num2);

        while (num1 != num2) {
            if (num1 > num2) {
                num1 = num1 - num2;
            } else {
                num2 = num2 - num1;
            }

        }

        System.out.println("The GCD is: " + num1);
    }
}
